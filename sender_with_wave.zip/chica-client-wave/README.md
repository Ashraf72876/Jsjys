# Chica Client — دليل البناء اليدوي (بدون Android Studio)

## قبل أي شي: خطوة واحدة ضرورية عندك

كل شي هون جاهز **إلا ملف واحد ثنائي (binary)**: `gradle/wrapper/gradle-wrapper.jar`.
هاد الملف مو كود مصدري، هو jar مبني من Gradle نفسه — ما قدرت أولّده من عندي لأنو ما عندي وصول
لشبكة الإنترنت هلق. الحل بسيط، اختر واحدة:

### الخيار أ (لو عندك Gradle مثبت عندك بأي نسخة):
```bash
cd chica-client
gradle wrapper --gradle-version 8.4 --distribution-type bin
```
هاد بيولّد `gradle-wrapper.jar` تلقائيًا ليطابق `gradle-wrapper.properties` الموجود.
بعدها استخدم `./gradlew` (أو `gradlew.bat` على ويندوز) عادي.

### الخيار ب (لو ما عندك Gradle إطلاقًا):
نزّل `gradle-8.4-bin.zip` من https://gradle.org/releases/ يدويًا، فكّه، واستخدم مساره مباشرة:
```bash
/path/to/gradle-8.4/bin/gradle assembleDebug -p chica-client
```
(بدون الحاجة لـ gradlew إطلاقًا بهالحالة)

---

## 1. عدّل `local.properties`
افتح `local.properties` بالجذر وحط مسار الـ Android SDK الحقيقي عندك:
```properties
sdk.dir=/path/to/your/Android/Sdk
```

## 2. تحقق إنو عندك:
- **JDK 17** (متطلب AGP 8.1.2) — تحقق بـ `java -version`
- **Android SDK** فيه على الأقل: `platform-33`, `build-tools;33.0.x`

لو ناقصك حزم الـ SDK وعندك `sdkmanager` بالأدوات يدوي:
```bash
sdkmanager "platforms;android-33" "build-tools;33.0.2"
```

## 3. ابنِ APK (Debug)
```bash
cd chica-client
./gradlew assembleDebug
```
(على ويندوز: `gradlew.bat assembleDebug`)

الناتج بيطلعلك بـ:
```
app/build/outputs/apk/debug/app-debug.apk
```

## 4. ثبّته على الجهاز/المحاكي (لو عندك adb)
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

---

## هيكلية المشروع

```
chica-client/
├── build.gradle                  # AGP 8.1.2 (مطابق للـ APK الأصلي بالضبط)
├── settings.gradle
├── gradle.properties
├── local.properties               # ⚠️ عدّل sdk.dir
├── gradlew / gradlew.bat
├── gradle/wrapper/
│   └── gradle-wrapper.properties  # Gradle 8.4
└── app/
    ├── build.gradle                # compileSdk 33 / minSdk 23 / targetSdk 33
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml     # أذونات INTERNET + ACCESS_NETWORK_STATE
        ├── res/                    # كل الموارد الأصلية (layouts, drawables, values, anim...)
        └── java/chica/
            ├── chicaclient/
            │   ├── MainActivity.java
            │   ├── ControlFragment.java
            │   ├── ModeFragment.java
            │   ├── ConnectFragment.java
            │   ├── TouchPad.java
            │   └── net/
            │       ├── RobotState.java
            │       ├── NetworkScannerThread.java
            │       └── ClientSessionThread.java
```

## ملاحظات مهمة
- `res/` و`AndroidManifest.xml` منسوخين من فك `apktool` (أدق أداة لفك الموارد الثنائية)، مو من jadx.
- الأذونات (`INTERNET`, `ACCESS_NETWORK_STATE`) موجودة وضرورية — من دونها التطبيق ما رح يقدر يفتح Socket عالمنفذ 18711 إطلاقًا.
- شلت من المانيفست إشارات خاصة بـ Google Play (splits/stamp) لأنها مش لازمة لبناء محلي، وشلت صلاحية `DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION` لأنها بتنضاف تلقائيًا من AGP وقت البناء عند الحاجة، مو المفروض تتكتب يدوي.
