# Add project specific ProGuard rules here.
# minifyEnabled is off by default in this build, so this file is currently unused,
# but is kept so build.gradle's proguardFiles reference doesn't fail if you enable it later.
