package chica.chicaclient;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.tabs.TabLayout;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

import chica.android.R;
import chica.chicaclient.net.NetworkScannerThread;
import chica.chicaclient.net.RobotState;

/**
 * Main activity: hosts the Mode / Control / Connect tabs and the robot communication protocol.
 * <p>
 * This is a clean rewrite of the original decompiled {@code chica.chicaclient.MainActivity}.
 * The network protocol (port, handshake, "ready"/"busy"/"bye" message handling, command-rate
 * measurement) is preserved exactly.
 * <p>
 * The activity's layout has a single {@code FragmentContainerView} plus a plain
 * {@code TabLayout} with static tab items (Mode, Control, Connect) - there is no ViewPager2 in
 * the project. Tab switching is therefore done with a manual FragmentTransaction driven
 * by a {@link TabLayout.OnTabSelectedListener}, which is the standard pattern for that layout
 * shape. (The original obfuscated tab listener class only exposed a stored, unused callback
 * reference and no method bodies - consistent with it having relied entirely on the interface's
 * default no-op methods - so the actual fragment-swapping wiring could not be recovered
 * byte-for-byte and is rebuilt here in the idiomatic way.)
 */
public class MainActivity extends AppCompatActivity {

    /** TCP port the robot's onboard server listens on. Preserved exactly from the original app. */
    public static final int ROBOT_PORT = 18711;

    private final ModeFragment modeFragment = new ModeFragment();
    private final ControlFragment controlFragment = new ControlFragment();
    private final ConnectFragment connectFragment = new ConnectFragment();

    /**
     * host -> pending outgoing command (or null if no command queued yet).
     * A host is present as a key exactly while a session for it is active.
     */
    private final Map<String, String> pendingHosts = new HashMap<>();

    /** Index of the tab currently shown in the fragment container: 0=Mode, 1=Control, 2=Connect. */
    private int visibleTabIndex = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        modeFragment.setHostActivity(this);
        controlFragment.setHostActivity(this);
        connectFragment.setHostActivity(this);

        TabLayout tabLayout = findViewById(R.id.tabLayout);
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                showTab(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });

        // The Control tab is the default landing tab.
        TabLayout.Tab controlTab = tabLayout.getTabAt(1);
        if (controlTab != null) {
            controlTab.select();
        } else {
            showTab(1);
        }

        new NetworkScannerThread(this).start();
    }

    private void showTab(int position) {
        visibleTabIndex = position;
        Fragment fragment;
        switch (position) {
            case 0:
                fragment = modeFragment;
                break;
            case 2:
                fragment = connectFragment;
                break;
            default:
                fragment = controlFragment;
                break;
        }
        getSupportFragmentManager()
                .beginTransaction()
                .setReorderingAllowed(true)
                .setCustomAnimations(R.anim.slide_in, R.anim.slide_out)
                .replace(R.id.fragmentContainerView, fragment)
                .commit();
    }

    public Map<String, String> getPendingHosts() {
        return pendingHosts;
    }

    public ConnectFragment getConnectFragment() {
        return connectFragment;
    }

    /** Queues {@code command} to be sent to the robot(s) over every currently pending connection. */
    public void queueCommandForAllHosts(String command) {
        synchronized (pendingHosts) {
            for (String host : pendingHosts.keySet()) {
                pendingHosts.put(host, command);
            }
        }
    }

    /**
     * Parses a "FLAGS=" telemetry segment (if present) into {@link chica.chicaclient.net.RobotState},
     * then refreshes whichever tab is currently visible.
     */
    public void updateConnectionStatus(String status) {
        if (status == null) {
            return;
        }

        int flagsIndex = status.indexOf("FLAGS=");
        if (flagsIndex >= 0) {
            int start = flagsIndex + 6;
            if (start + 9 <= status.length()) {
                String flagsBlock = status.substring(start, start + 9);
                if (flagsBlock.length() == 9) {
                    char[] flags = flagsBlock.toCharArray();
                    RobotState state = RobotState.INSTANCE;
                    state.torque = flags[0] == '1';
                    state.stand = flags[1] == '1';
                    state.keepBody = flags[2] == '1';
                    state.crabWalk = flags[3] == '1';
                    state.mode = Integer.parseInt(String.valueOf(flags[4]));
                    state.autoLevel = flags[5] == '1';
                    state.autoSit = flags[6] == '1';
                    state.block = flags[7] == '1';
                    state.calibPos = flags[8] == '1';
                }
            }
        }

        switch (visibleTabIndex) {
            case 2:
                connectFragment.showDiagnostics(formatDiagnostics(status));
                break;
            case 1:
                controlFragment.refreshButtonStates();
                break;
            default:
                modeFragment.refreshButtonStates();
                break;
        }
    }

    private static String formatDiagnostics(String status) {
        return status
                .replace("BPS=", "  BPS: ")
                .replace("|V=", "\n    V: ")
                .replace("|I=", "\n    I: ")
                .replace("|IP=", "\n   IP: ")
                .replace("|LEGS=", "\n LEGS: ")
                .replace("|FLAGS=", "\nFLAGS: ");
    }

    /**
     * Runs the request/response protocol for a single robot connection until the connection ends.
     * <p>
     * Protocol (unchanged from the original app):
     * <ul>
     *   <li>Every line starting with "ready" is a heartbeat; the server expects either the
     *       currently-queued command for this host, or "ack" if none is queued.</li>
     *   <li>Every line starting with "busy" just gets acknowledged with "ack" after a short pause.</li>
     *   <li>Any other line is treated as unknown and ends the session with "bye".</li>
     *   <li>A line that is exactly "bye" ends the session immediately.</li>
     * </ul>
     * Only the primary connection (the first host to connect) drives the on-screen command-rate
     * and diagnostics display.
     * <p>
     * Note: the original decompiled bytecode had an ambiguous/duplicated response-write for the
     * "ready + command queued" case (an artifact of decompiling optimized bytecode, not a
     * deliberate protocol feature). This version sends exactly one response per received line,
     * which is the only behaviour consistent with a request/response heartbeat protocol.
     */
    public static void runProtocolSession(MainActivity activity, Socket socket, String host, boolean isPrimaryConnection)
            throws IOException {
        long windowStart = System.currentTimeMillis();
        int readyCountInWindow = 0;

        try (PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            String line;
            while ((line = in.readLine()) != null) {
                if (line.equals("bye")) {
                    break;
                }

                String response;
                if (line.startsWith("ready")) {
                    readyCountInWindow++;
                    long now = System.currentTimeMillis();
                    long elapsed = now - windowStart;
                    if (elapsed > 1000) {
                        float commandsPerSecond = readyCountInWindow * 1000.0f / elapsed;
                        if (isPrimaryConnection) {
                            activity.runOnUiThread(() -> activity.controlFragment.updateCommandRateDisplay(commandsPerSecond));
                        }
                        readyCountInWindow = 0;
                        windowStart = now;
                    }

                    if (isPrimaryConnection) {
                        activity.updateConnectionStatus(line.substring(6));
                    }

                    String queuedCommand;
                    synchronized (activity.pendingHosts) {
                        queuedCommand = activity.pendingHosts.get(host);
                        activity.pendingHosts.put(host, null);
                    }

                    if (queuedCommand != null) {
                        response = queuedCommand;
                    } else {
                        Thread.sleep(100L);
                        response = "ack";
                    }
                } else if (line.startsWith("busy")) {
                    if (isPrimaryConnection) {
                        activity.updateConnectionStatus(line.substring(5));
                    }
                    Thread.sleep(100L);
                    response = "ack";
                } else {
                    System.out.println("Unknown command " + line);
                    response = "bye";
                }

                out.println(response);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            if (isPrimaryConnection) {
                activity.runOnUiThread(() -> activity.controlFragment.updateCommandRateDisplay(0.0f));
            }
        }
    }
}
