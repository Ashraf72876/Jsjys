package chica.chicaclient;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import androidx.appcompat.widget.AppCompatImageView;

/**
 * Simple joystick surface: draws a grey dot at the last known touch/tilt position, expressed
 * as fractions of the view's width/height in [0, 1]. Clean rewrite of the decompiled
 * {@code chica.chicaclient.TouchPad} (which extended the AppCompat image-view base class).
 */
public class TouchPad extends AppCompatImageView {

    private static final float DOT_RADIUS_PX = 30.0f;
    private static final int DOT_COLOR = 0xFF888888; // matches original color value -7829368

    /** Last known touch/tilt position, as a fraction of width/height. Off-screen by default. */
    public float positionX = -10.0f;
    public float positionY = -10.0f;

    private final Paint dotPaint;

    public TouchPad(Context context, AttributeSet attrs) {
        super(context, attrs, 0);
        dotPaint = new Paint();
        dotPaint.setColor(DOT_COLOR);
    }

    @Override
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawCircle(positionX * canvas.getWidth(), positionY * canvas.getHeight(), DOT_RADIUS_PX, dotPaint);
    }
}
