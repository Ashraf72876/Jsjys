package chica.chicaclient.net;

import chica.chicaclient.MainActivity;

import java.net.Socket;

/**
 * Runs a single robot connection's request/response session on its own thread, then always
 * removes that host from the shared "pending hosts" map when the session ends, whether it
 * ended normally or via an exception.
 * <p>
 * Clean rewrite of the obfuscated class {@code d1.m}.
 */
public final class ClientSessionThread extends Thread {

    private final MainActivity activity;
    private final Socket socket;
    private final String host;
    private final boolean isPrimaryConnection;

    public ClientSessionThread(MainActivity activity, Socket socket, String host, boolean isPrimaryConnection) {
        this.activity = activity;
        this.socket = socket;
        this.host = host;
        this.isPrimaryConnection = isPrimaryConnection;
    }

    @Override
    public void run() {
        try {
            MainActivity.runProtocolSession(activity, socket, host, isPrimaryConnection);
        } catch (Exception ignored) {
            // Matches original behaviour: any failure just ends this session silently.
        } finally {
            synchronized (activity.getPendingHosts()) {
                activity.getPendingHosts().remove(host);
            }
        }
    }
}
