package chica.chicaclient.net;

/**
 * Shared, process-wide state for the currently selected robot options.
 * <p>
 * This mirrors the original obfuscated class {@code d1.a}. It was a plain data holder with
 * volatile fields (safe to touch from the UI thread, the sensor callback thread, and the
 * network I/O thread at the same time), so that behaviour is preserved exactly here.
 * <p>
 * Field mapping back to the decompiled names, for traceability:
 * <pre>
 *   f1758a -> keepBody
 *   f1759b -> crabWalk
 *   f1760c -> stand
 *   f1761d -> torque
 *   f1762e -> autoLevel
 *   f1763f -> autoSit
 *   f1764g -> block
 *   f1765h -> calibPos
 *   f1766i -> walkStyle   (0..7)
 *   f1767j -> mode        (0=standard, 1=race, 2=offroad, 3=custom, 4=quadruped)
 *   f1768k -> quadLeg1    (index into LEG_NAMES, default 1)
 *   f1769l -> quadLeg2    (index into LEG_NAMES, default 4)
 * </pre>
 */
public final class RobotState {

    /** Singleton instance, matching the single static field MainActivity.B in the original app. */
    public static final RobotState INSTANCE = new RobotState();

    public volatile boolean keepBody = false;
    public volatile boolean crabWalk = false;
    public volatile boolean stand = false;
    public volatile boolean torque = false;
    public volatile boolean autoLevel = false;
    public volatile boolean autoSit = false;
    public volatile boolean block = false;
    public volatile boolean calibPos = false;

    /** Current walk style, cycles through 0..7. */
    public volatile int walkStyle = 0;

    /** Drive mode: 0=standard, 1=race, 2=offroad, 3=custom, 4=quadruped. */
    public volatile int mode = 0;

    /** Selected quadruped-mode leg indices (into {@link #LEG_NAMES}). Defaults preserved exactly. */
    public volatile int quadLeg1 = 1;
    public volatile int quadLeg2 = 4;

    /** Leg names used by quadruped mode leg pickers ("L1","L2","L3","R1","R2","R3"). */
    public static final String[] LEG_NAMES = {"L1", "L2", "L3", "R1", "R2", "R3"};

    /** Human-readable walk-style labels shown on the walk-style button. */
    public static final String[] WALK_STYLE_LABELS =
            {"NONE", "1 ZW", "2 XV", "3 XU", "4 YW", "5 XV", "6 XY", "7 XYVW"};

    private RobotState() {
    }
}
