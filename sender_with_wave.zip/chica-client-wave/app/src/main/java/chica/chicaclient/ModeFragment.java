package chica.chicaclient;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import chica.android.R;
import chica.chicaclient.net.RobotState;

/**
 * The drive-mode tab: standard / race / offroad / custom / quadruped mode selection, the
 * quadruped leg pickers, and the maintenance buttons (reboot/restart/calibrate/block/calibpos).
 * <p>
 * Clean rewrite of the obfuscated fragment class {@code d1.o}.
 */
public class ModeFragment extends Fragment {

    private MainActivity hostActivity;
    private View rootView;

    public void setHostActivity(MainActivity activity) {
        this.hostActivity = activity;
    }

    private void sendCommand(String command) {
        if (hostActivity != null) {
            hostActivity.queueCommandForAllHosts(command);
        }
    }

    private void setButtonHighlight(int viewId, boolean highlighted, boolean useAlternateColor) {
        if (rootView == null) {
            return;
        }
        int color = highlighted ? (useAlternateColor ? 0xFF00FFFF : 0xFFFFFF00) : 0xFF000000;
        ((Button) rootView.findViewById(viewId)).setTextColor(color);
    }

    /** Refreshes mode/leg-picker button highlighting and labels from {@link RobotState}. */
    public void refreshButtonStates() {
        RobotState state = RobotState.INSTANCE;

        setButtonHighlight(R.id.standardMode, state.mode == 0, false);
        setButtonHighlight(R.id.raceMode, state.mode == 1, false);
        setButtonHighlight(R.id.offroadMode, state.mode == 2, false);
        setButtonHighlight(R.id.customMode, state.mode == 3, false);

        boolean isQuadrupedMode = state.mode == 4;
        setButtonHighlight(R.id.quadrupedB52, isQuadrupedMode, false);
        setButtonHighlight(R.id.quadLeg1B62, isQuadrupedMode, false);
        setButtonHighlight(R.id.quadLeg2B63, isQuadrupedMode, false);

        if (rootView != null) {
            ((Button) rootView.findViewById(R.id.quadLeg1B62)).setText(RobotState.LEG_NAMES[state.quadLeg1]);
            ((Button) rootView.findViewById(R.id.quadLeg2B63)).setText(RobotState.LEG_NAMES[state.quadLeg2]);
        }

        setButtonHighlight(R.id.block, state.block, true);
        setButtonHighlight(R.id.calibpos, state.calibPos, true);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_mode, container, false);
        refreshButtonStates();

        rootView.findViewById(R.id.calibpos).setOnClickListener(v -> sendCommand("calibpos"));
        rootView.findViewById(R.id.block).setOnClickListener(v -> sendCommand("block"));
        rootView.findViewById(R.id.reboot).setOnClickListener(v -> sendCommand("reboot"));
        rootView.findViewById(R.id.restart).setOnClickListener(v -> sendCommand("restart"));
        rootView.findViewById(R.id.calibrate).setOnClickListener(v -> sendCommand("calibrate"));

        rootView.findViewById(R.id.standardMode).setOnClickListener(v -> sendCommand("standard"));
        rootView.findViewById(R.id.raceMode).setOnClickListener(v -> sendCommand("race"));
        rootView.findViewById(R.id.offroadMode).setOnClickListener(v -> sendCommand("offroad"));
        rootView.findViewById(R.id.customMode).setOnClickListener(v -> sendCommand("custom"));

        // Preserved exactly from the decompiled source: the leg pickers only advance while NOT
        // in quadruped mode (mode != 4). Quadruped mode itself does not let you re-pick legs
        // from here; whatever pair was selected beforehand is what gets sent by the "quad:"
        // button below.
        rootView.findViewById(R.id.quadLeg1B62).setOnClickListener(v -> {
            RobotState state = RobotState.INSTANCE;
            if (state.mode != 4) {
                state.quadLeg1 = (state.quadLeg1 + 1) % RobotState.LEG_NAMES.length;
                if (state.quadLeg1 == state.quadLeg2) {
                    state.quadLeg1 = (state.quadLeg1 + 1) % RobotState.LEG_NAMES.length;
                }
                refreshButtonStates();
            }
        });
        rootView.findViewById(R.id.quadLeg2B63).setOnClickListener(v -> {
            RobotState state = RobotState.INSTANCE;
            if (state.mode != 4) {
                state.quadLeg2 = (state.quadLeg2 + 1) % RobotState.LEG_NAMES.length;
                if (state.quadLeg1 == state.quadLeg2) {
                    state.quadLeg2 = (state.quadLeg2 + 1) % RobotState.LEG_NAMES.length;
                }
                refreshButtonStates();
            }
        });
        rootView.findViewById(R.id.quadrupedB52).setOnClickListener(v -> {
            RobotState state = RobotState.INSTANCE;
            sendCommand("quad:" + state.quadLeg1 + "," + state.quadLeg2);
        });

        return rootView;
    }
}
