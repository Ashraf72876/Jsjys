package chica.chicaclient;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import chica.android.R;

/**
 * The connection-settings tab: lets the user view/edit the list of candidate robot host
 * addresses that {@link chica.chicaclient.net.NetworkScannerThread} will try, persists that
 * list to a small config file, and shows live connection diagnostics.
 * <p>
 * Clean rewrite of the obfuscated fragment class {@code d1.c}.
 */
public class ConnectFragment extends Fragment {

    /** Default host list, used until the user saves a custom one. */
    public static final String[] DEFAULT_HOSTS = {"192.168.0.2", "192.168.0.4", "192.168.0.8", "192.168.0.16"};

    private static final String CONFIG_FILE_NAME = "host-names.cfg";

    /** Currently configured hosts, or {@code null} if the user hasn't saved a custom list yet. */
    private static volatile String[] configuredHosts;
    private static File configFile;

    private MainActivity hostActivity;
    private TextView diagnosticsTextView;
    private EditText hostListEditText;

    public void setHostActivity(MainActivity activity) {
        this.hostActivity = activity;
    }

    /** Returns the currently configured host list, falling back to {@link #DEFAULT_HOSTS}. */
    public static String[] getConfiguredHosts() {
        String[] hosts = configuredHosts;
        return hosts != null ? hosts : DEFAULT_HOSTS;
    }

    /**
     * Parses and validates a raw list of IPv4 addresses (one per input entry): trims whitespace,
     * discards blank entries, and requires exactly 4 dot-separated octets each in [0, 255].
     * Falls back to {@link #DEFAULT_HOSTS} if nothing valid remains.
     */
    private static String[] parseAndValidateHosts(String[] rawEntries) {
        List<String> validHosts = new ArrayList<>();
        for (String raw : rawEntries) {
            if (raw == null) {
                continue;
            }
            String trimmed = raw.trim();
            if (isValidIpv4(trimmed)) {
                validHosts.add(trimmed);
            }
        }
        return validHosts.isEmpty() ? DEFAULT_HOSTS : validHosts.toArray(new String[0]);
    }

    private static boolean isValidIpv4(String candidate) {
        if (candidate.isEmpty()) {
            return false;
        }
        String[] octets = candidate.split("\\.");
        if (octets.length != 4) {
            return false;
        }
        for (String octet : octets) {
            if (octet.isEmpty()) {
                return false;
            }
            try {
                int value = Integer.parseInt(octet);
                if (value < 0 || value > 255) {
                    return false;
                }
            } catch (NumberFormatException e) {
                return false;
            }
        }
        return true;
    }

    /** Persists {@link #configuredHosts} to {@link #configFile} as a comma-separated list. */
    private static void saveConfiguredHosts() {
        try {
            if (configFile == null) {
                return;
            }
            if (!configFile.exists()) {
                configFile.createNewFile();
            }
            StringBuilder contents = new StringBuilder();
            for (String host : configuredHosts) {
                contents.append(host).append(",");
            }
            try (FileOutputStream out = new FileOutputStream(configFile)) {
                out.write(contents.toString().getBytes());
                out.flush();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    /** Refreshes the host-list text field from {@link #configuredHosts} / {@link #DEFAULT_HOSTS}. */
    private void refreshHostListText() {
        if (hostListEditText == null) {
            return;
        }
        StringBuilder text = new StringBuilder();
        for (String host : getConfiguredHosts()) {
            text.append(host).append("\r\n");
        }
        hostListEditText.setText(text.toString());
    }

    /** Shows a freshly formatted diagnostics string (called by {@link MainActivity}). */
    public void showDiagnostics(String formattedDiagnostics) {
        if (diagnosticsTextView != null) {
            diagnosticsTextView.setText(formattedDiagnostics);
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_connect, container, false);
        diagnosticsTextView = view.findViewById(R.id.infoTextView);
        hostListEditText = view.findViewById(R.id.ipListEditText);

        configFile = new File(requireContext().getFilesDir(), CONFIG_FILE_NAME);
        try {
            if (configFile.exists()) {
                try (FileInputStream in = new FileInputStream(configFile)) {
                    byte[] buffer = new byte[1024];
                    int read = in.read(buffer);
                    String[] rawEntries = new String(buffer, 0, read).split(",");
                    configuredHosts = parseAndValidateHosts(rawEntries);
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        refreshHostListText();

        view.findViewById(R.id.saveIpList).setOnClickListener(v -> {
            configuredHosts = parseAndValidateHosts(hostListEditText.getText().toString().split("\n"));
            saveConfiguredHosts();
            refreshHostListText();
        });

        view.findViewById(R.id.resetIpList).setOnClickListener(v -> {
            configuredHosts = DEFAULT_HOSTS;
            saveConfiguredHosts();
            refreshHostListText();
        });

        view.findViewById(R.id.privacyPolicy).setOnClickListener(v -> {
            Intent intent = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER);
            intent.setData(Uri.parse("https://www.makeyourpet.com/privacy-policy"));
            startActivity(intent);
        });

        return view;
    }
}
