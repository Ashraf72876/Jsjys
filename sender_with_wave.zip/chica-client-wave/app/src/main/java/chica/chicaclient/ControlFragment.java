package chica.chicaclient;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import chica.android.R;
import chica.chicaclient.net.RobotState;

/**
 * The main driving tab: joystick / tilt control, gait selection, and the various one-shot
 * and toggle command buttons.
 * <p>
 * Clean rewrite of the obfuscated fragment class {@code d1.g}, its touch listener
 * {@code d1.d}, and its button-click dispatcher {@code d1.e}. All thresholds, scale factors,
 * command name strings and the exact argument order sent to the robot are preserved exactly
 * as recovered from the CFR decompilation (the original JADX output could not fully structure
 * this method's control flow).
 */
public class ControlFragment extends Fragment implements SensorEventListener {

    // Control modes (values match the wire protocol / original obfuscated field "Z" exactly).
    private static final int MODE_SET_XY = 1;
    private static final int MODE_SET_ZU = 2;
    private static final int MODE_SET_VW = 3;
    private static final int MODE_SET_XYVW = 4;
    private static final int MODE_WALK3 = 5;
    private static final int MODE_WALK2 = 6;
    private static final int MODE_WALK1 = 7;
    private static final int MODE_WALK1P5 = 8;
    private static final int MODE_WALK2P5 = 9;
    private static final int MODE_SET_ROTATE = 10;
    private static final int MODE_SET_DIVE = 11;
    private static final int MODE_WALK_WAVE = 12;

    /** Deadzone applied to each joystick axis before rescaling, in wide-axis mode only. */
    private static final float DEADZONE = 0.2f;
    /** Rescale divisor so that values just outside the deadzone still reach +-1.0 smoothly. */
    private static final float DEADZONE_RESCALE = 0.8f;

    private MainActivity hostActivity;
    private View rootView;
    private TextView commandRateTextView;
    private TextView gyroRateTextView;
    private TouchPad touchPad;
    private SensorManager sensorManager;
    private Sensor rotationVectorSensor;

    private boolean wideAxisMode = false;
    private boolean gyroEnabled = false;
    private int activeControlMode = MODE_SET_XY;

    private long gyroWindowStart = 0L;
    private int gyroSampleCountInWindow = 0;

    public void setHostActivity(MainActivity activity) {
        this.hostActivity = activity;
    }

    // ---------------------------------------------------------------------------------------
    // Movement command construction
    // ---------------------------------------------------------------------------------------

    /**
     * Converts a pair of raw axis readings (each roughly in [-1, 1]) into a movement command
     * for the currently selected control mode, and sends it to the robot.
     * <p>
     * When "wide axis" mode is enabled, a small deadzone is removed from the center of each
     * axis and the remaining range is rescaled back out to [-1, 1]. This exactly mirrors the
     * decompiled logic: values within +-0.2 of center become 0, and values beyond that are
     * shifted toward zero by 0.2 and divided by 0.8.
     *
     * @param axisA first raw axis reading
     * @param axisB second raw axis reading
     */
    private void sendMovementCommand(float axisA, float axisB) {
        float a = axisA;
        float b = axisB;

        if (wideAxisMode) {
            a = applyDeadzone(axisA);
            b = applyDeadzone(axisB);
        }

        float bInverted = -b;
        String commandName;
        boolean isGaitCommand;

        switch (activeControlMode) {
            case MODE_SET_XY:     commandName = "setxy";     isGaitCommand = false; break;
            case MODE_SET_ZU:     commandName = "setzu";     isGaitCommand = false; break;
            case MODE_SET_VW:     commandName = "setvw";     isGaitCommand = false; break;
            case MODE_SET_XYVW:   commandName = "setxyvw";   isGaitCommand = false; break;
            case MODE_WALK3:      commandName = "walk3";     isGaitCommand = true;  break;
            case MODE_WALK2:      commandName = "walk2";     isGaitCommand = true;  break;
            case MODE_WALK1:      commandName = "walk1";     isGaitCommand = true;  break;
            case MODE_WALK1P5:    commandName = "walk15";    isGaitCommand = true;  break;
            case MODE_WALK2P5:    commandName = "walk25";    isGaitCommand = true;  break;
            case MODE_SET_ROTATE: commandName = "setrotate"; isGaitCommand = false; break;
            case MODE_SET_DIVE:   commandName = "setdive";   isGaitCommand = false; break;
            case MODE_WALK_WAVE:  commandName = "walkwave";  isGaitCommand = true;  break;
            default:
                // Original decompiled code sends nothing for an unrecognized/idle mode.
                return;
        }

        StringBuilder command = new StringBuilder(commandName).append(':').append(a).append(',').append(bInverted);
        if (isGaitCommand) {
            command.append(',').append(RobotState.INSTANCE.walkStyle);
        }
        sendCommand(command.toString());
    }

    private static float applyDeadzone(float value) {
        if (value < -DEADZONE) {
            return (value + DEADZONE) / DEADZONE_RESCALE;
        } else if (value > DEADZONE) {
            return (value - DEADZONE) / DEADZONE_RESCALE;
        } else {
            return 0f;
        }
    }

    // ---------------------------------------------------------------------------------------
    // Touch input
    // ---------------------------------------------------------------------------------------

    private boolean onTouchPadTouch(View view, MotionEvent event) {
        if (gyroEnabled) {
            // While tilt control is active, the touch pad does not also drive movement.
            return false;
        }

        int action = event.getAction();
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE) {
            float y = clamp01(event.getY() / view.getHeight()) * 2.0f - 1.0f;
            float x = clamp01(event.getX() / view.getWidth()) * 2.0f - 1.0f;
            sendMovementCommand(y, x);
            return true;
        } else if (action == MotionEvent.ACTION_UP) {
            sendCommand("clear");
            return true;
        }
        return false;
    }

    private static float clamp01(float value) {
        return Math.max(0f, Math.min(1f, value));
    }

    // ---------------------------------------------------------------------------------------
    // Tilt (rotation-vector sensor) input
    // ---------------------------------------------------------------------------------------

    private void setGyroEnabled(boolean enabled) {
        if (enabled == gyroEnabled) {
            return;
        }
        if (enabled) {
            sensorManager.registerListener(this, rotationVectorSensor, SensorManager.SENSOR_DELAY_FASTEST, SensorManager.SENSOR_DELAY_FASTEST);
        } else {
            sensorManager.unregisterListener(this);
            touchPad.positionX = -4.5f;
            touchPad.positionY = -4.5f;
            touchPad.invalidate();
            sendCommand("clear");
            gyroRateTextView.setText("");
        }
        gyroEnabled = enabled;
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not used.
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (!gyroEnabled || event.sensor.getType() != Sensor.TYPE_ROTATION_VECTOR) {
            return;
        }

        gyroSampleCountInWindow++;
        long now = System.currentTimeMillis();
        long elapsed = now - gyroWindowStart;
        if (elapsed > 1000) {
            String rateText = String.format("% 5.2f", gyroSampleCountInWindow * 1000.0f / elapsed);
            requireActivity().runOnUiThread(() -> gyroRateTextView.setText(rateText));
            gyroWindowStart = now;
            gyroSampleCountInWindow = 0;
        }

        float tiltA = event.values[0] / 5.0f;
        float tiltB = event.values[1] / 5.0f;
        if (tiltA < -1.0f || tiltA > 1.0f || tiltB < -1.0f || tiltB > 1.0f) {
            return;
        }

        requireActivity().runOnUiThread(() -> {
            touchPad.positionX = (-tiltA + 1.0f) / 2.0f;
            touchPad.positionY = (tiltB + 1.0f) / 2.0f;
            touchPad.invalidate();
        });
        sendMovementCommand(tiltB, -tiltA);
    }

    // ---------------------------------------------------------------------------------------
    // Command dispatch + UI refresh
    // ---------------------------------------------------------------------------------------

    private void sendCommand(String command) {
        if (hostActivity != null) {
            hostActivity.queueCommandForAllHosts(command);
        }
    }

    private void setButtonHighlight(int viewId, boolean highlighted, boolean useAlternateColor) {
        if (rootView == null) {
            return;
        }
        int color = highlighted ? (useAlternateColor ? 0xFF00FFFF : 0xFFFFFF00) : 0xFF000000;
        ((Button) rootView.findViewById(viewId)).setTextColor(color);
    }

    private void setActiveControlMode(int mode) {
        activeControlMode = mode;
        refreshButtonStates();
    }

    /** Called on the UI thread when new telemetry/flags arrive, to refresh all toggle buttons. */
    public void refreshButtonStates() {
        setButtonHighlight(R.id.moveXYB11, activeControlMode == MODE_SET_XY, false);
        setButtonHighlight(R.id.moveZUB12, activeControlMode == MODE_SET_ZU, false);
        setButtonHighlight(R.id.turnVWB13, activeControlMode == MODE_SET_VW, false);
        setButtonHighlight(R.id.comboMoveB14, activeControlMode == MODE_SET_XYVW, false);
        setButtonHighlight(R.id.rotateB21, activeControlMode == MODE_SET_ROTATE, false);
        setButtonHighlight(R.id.diveB22, activeControlMode == MODE_SET_DIVE, false);
        setButtonHighlight(R.id.walk3_3B31, activeControlMode == MODE_WALK3, false);
        setButtonHighlight(R.id.walk2_2B32, activeControlMode == MODE_WALK2, false);
        setButtonHighlight(R.id.walk1_1B33, activeControlMode == MODE_WALK1, false);
        setButtonHighlight(R.id.walk1p5B42, activeControlMode == MODE_WALK1P5, false);
        setButtonHighlight(R.id.walk2p5B41, activeControlMode == MODE_WALK2P5, false);
        setButtonHighlight(R.id.walkWaveB43, activeControlMode == MODE_WALK_WAVE, false);

        RobotState state = RobotState.INSTANCE;
        setButtonHighlight(R.id.crabWalkB34, state.crabWalk, true);
        setButtonHighlight(R.id.keepBodyB24, state.keepBody, true);
        setButtonHighlight(R.id.wideAxisB23, wideAxisMode, true);
        setButtonHighlight(R.id.torqueB51, state.torque, true);
        setButtonHighlight(R.id.standB53, state.stand, true);
        setButtonHighlight(R.id.gyroB54, gyroEnabled, true);
        setButtonHighlight(R.id.autoLevelB73, state.autoLevel, true);
        setButtonHighlight(R.id.autoSitB63, state.autoSit, true);
        setButtonHighlight(R.id.walkStyleB61, state.walkStyle != 0, true);

        if (rootView != null) {
            String label = "Style\n" + RobotState.WALK_STYLE_LABELS[state.walkStyle];
            ((Button) rootView.findViewById(R.id.walkStyleB61)).setText(label);
        }
    }

    void updateCommandRateDisplay(float commandsPerSecond) {
        if (commandRateTextView != null) {
            commandRateTextView.setText(String.format("% 5.2f", commandsPerSecond));
        }
    }

    // ---------------------------------------------------------------------------------------
    // Fragment lifecycle
    // ---------------------------------------------------------------------------------------

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        sensorManager = (SensorManager) requireActivity().getSystemService(Context.SENSOR_SERVICE);
        rotationVectorSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);

        rootView = inflater.inflate(R.layout.fragment_control, container, false);
        refreshButtonStates();

        touchPad = rootView.findViewById(R.id.touchPad);
        touchPad.setOnTouchListener(this::onTouchPadTouch);

        rootView.findViewById(R.id.moveXYB11).setOnClickListener(v -> setActiveControlMode(MODE_SET_XY));
        rootView.findViewById(R.id.moveZUB12).setOnClickListener(v -> setActiveControlMode(MODE_SET_ZU));
        rootView.findViewById(R.id.turnVWB13).setOnClickListener(v -> setActiveControlMode(MODE_SET_VW));
        rootView.findViewById(R.id.comboMoveB14).setOnClickListener(v -> setActiveControlMode(MODE_SET_XYVW));
        rootView.findViewById(R.id.rotateB21).setOnClickListener(v -> setActiveControlMode(MODE_SET_ROTATE));
        rootView.findViewById(R.id.diveB22).setOnClickListener(v -> setActiveControlMode(MODE_SET_DIVE));
        rootView.findViewById(R.id.walk3_3B31).setOnClickListener(v -> setActiveControlMode(MODE_WALK3));
        rootView.findViewById(R.id.walk2_2B32).setOnClickListener(v -> setActiveControlMode(MODE_WALK2));
        rootView.findViewById(R.id.walk1_1B33).setOnClickListener(v -> setActiveControlMode(MODE_WALK1));
        rootView.findViewById(R.id.walk1p5B42).setOnClickListener(v -> setActiveControlMode(MODE_WALK1P5));
        rootView.findViewById(R.id.walk2p5B41).setOnClickListener(v -> setActiveControlMode(MODE_WALK2P5));
        rootView.findViewById(R.id.walkWaveB43).setOnClickListener(v -> setActiveControlMode(MODE_WALK_WAVE));

        rootView.findViewById(R.id.beepB).setOnClickListener(v -> sendCommand("beep"));
        rootView.findViewById(R.id.bounceB).setOnClickListener(v -> sendCommand("bounce"));
        rootView.findViewById(R.id.jumpB).setOnClickListener(v -> sendCommand("jump"));
        rootView.findViewById(R.id.waveB).setOnClickListener(v -> sendCommand("wave"));

        rootView.findViewById(R.id.standB53).setOnClickListener(v -> {
            if (!gyroEnabled) sendCommand("sit"); else setGyroEnabled(false);
        });
        rootView.findViewById(R.id.torqueB51).setOnClickListener(v -> {
            if (!gyroEnabled) sendCommand("torque"); else setGyroEnabled(false);
        });
        rootView.findViewById(R.id.homeB44).setOnClickListener(v -> {
            if (!gyroEnabled) sendCommand("home"); else setGyroEnabled(false);
        });

        rootView.findViewById(R.id.autoLevelB73).setOnClickListener(v -> sendCommand("level"));
        rootView.findViewById(R.id.keepBodyB24).setOnClickListener(v -> sendCommand("keep"));
        rootView.findViewById(R.id.crabWalkB34).setOnClickListener(v -> sendCommand("crab"));
        rootView.findViewById(R.id.autoSitB63).setOnClickListener(v -> sendCommand("autosit"));

        rootView.findViewById(R.id.wideAxisB23).setOnClickListener(v -> {
            wideAxisMode = !wideAxisMode;
            refreshButtonStates();
        });
        rootView.findViewById(R.id.walkStyleB61).setOnClickListener(v -> {
            RobotState state = RobotState.INSTANCE;
            state.walkStyle = (state.walkStyle + 1) % RobotState.WALK_STYLE_LABELS.length;
            refreshButtonStates();
        });
        rootView.findViewById(R.id.gyroB54).setOnClickListener(v -> {
            setGyroEnabled(!gyroEnabled);
            refreshButtonStates();
        });

        commandRateTextView = rootView.findViewById(R.id.cmdCountTextView);
        gyroRateTextView = rootView.findViewById(R.id.gyroCountTextView);
        return rootView;
    }

    @Override
    public void onResume() {
        super.onResume();
        refreshButtonStates();
    }
}
