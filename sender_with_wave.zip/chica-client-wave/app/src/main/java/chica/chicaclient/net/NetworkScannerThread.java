package chica.chicaclient.net;

import chica.chicaclient.ConnectFragment;
import chica.chicaclient.MainActivity;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;

/**
 * Background thread that continuously probes every configured robot host on
 * {@link MainActivity#ROBOT_PORT} and, on success, hands the connected socket off to a
 * {@link ClientSessionThread}.
 * <p>
 * This is a clean rewrite of the obfuscated class {@code d1.l}. The connect/read-timeouts,
 * retry cadence, and the "primary connection" selection rule (the very first host that manages
 * to connect becomes the one whose telemetry is shown in the UI) are preserved exactly.
 */
public final class NetworkScannerThread extends Thread {

    private static final int CONNECT_TIMEOUT_MS = 200;
    private static final int SOCKET_READ_TIMEOUT_MS = 1000;
    private static final long RETRY_DELAY_MS = 100L;

    private final MainActivity activity;

    public NetworkScannerThread(MainActivity activity) {
        this.activity = activity;
    }

    @Override
    public void run() {
        while (true) {
            try {
                if (activity.getPendingHosts().isEmpty()) {
                    activity.updateConnectionStatus("---");
                }

                ConnectFragment connectFragment = activity.getConnectFragment();
                if (connectFragment == null) {
                    // No connect UI yet (e.g. activity is being recreated); try again shortly.
                    continue;
                }

                String[] hosts = ConnectFragment.getConfiguredHosts();
                for (String host : hosts) {
                    synchronized (activity.getPendingHosts()) {
                        if (!activity.getPendingHosts().containsKey(host)) {
                            tryConnect(host);
                        }
                    }
                    Thread.sleep(RETRY_DELAY_MS);
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }

    private void tryConnect(String host) {
        Socket socket;
        try {
            socket = new Socket();
        } catch (IOException e) {
            return;
        }

        try {
            socket.connect(new InetSocketAddress(host, MainActivity.ROBOT_PORT), CONNECT_TIMEOUT_MS);
            socket.setSoTimeout(SOCKET_READ_TIMEOUT_MS);
        } catch (IOException e) {
            closeQuietly(socket);
            return;
        }

        activity.getPendingHosts().put(host, null);
        boolean isPrimaryConnection = activity.getPendingHosts().size() == 1;
        new ClientSessionThread(activity, socket, host, isPrimaryConnection).start();
    }

    private static void closeQuietly(Socket socket) {
        try {
            socket.close();
        } catch (IOException ignored) {
            // Nothing sensible to do here.
        }
    }
}
